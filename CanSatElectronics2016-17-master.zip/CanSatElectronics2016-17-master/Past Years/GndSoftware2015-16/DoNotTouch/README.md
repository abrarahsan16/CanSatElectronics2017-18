# GndSoftware2015-16
Name = The PILOT.

Description = This is a piece of software that monitors and communicates with a miniature satellite for the CANSAT competition                2015. 
              This is a Property of the Ryerson Cansat Team, Team TOMAHAWK. 

We tha best!!
