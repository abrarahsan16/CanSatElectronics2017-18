if ('dddd' == 'dddd')
    1
end