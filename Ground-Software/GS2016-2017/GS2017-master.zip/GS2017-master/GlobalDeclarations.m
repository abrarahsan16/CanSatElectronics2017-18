global matrix
matrix.glider(1, 12) = 0 ;
matrix.container(1, 11) = 0;
global lastDevice
lastDevice = 'C';