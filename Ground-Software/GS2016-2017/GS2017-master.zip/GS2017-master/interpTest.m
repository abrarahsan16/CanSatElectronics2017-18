nm1 = 2;
nm2 = 1;

xx = [ 1 2]
yy = [nm2 nm1]

x = 3

val = interp1(xx, yy,x,'linear', 'extrap')