clear all;
warning('off', 'all');
gcs2017;